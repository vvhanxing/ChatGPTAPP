# Navvy the navigational ChatBot!

A Pen created on CodePen.io. Original URL: [https://codepen.io/meesrutten/pen/wgvpQM](https://codepen.io/meesrutten/pen/wgvpQM).

This is a chatbot I made with pure Javascript. It knows a few commands and after some commands you can answer "yes" or "no" to which it will reply