from flask import Flask, send_file, Response, send_from_directory
from flask import jsonify,request,render_template
import io
import re
import json
app = Flask(__name__)

@app.route("/chat/",methods = ["GET","POST"])
def chat():
    return render_template("index.html")


if __name__ == '__main__':
    app.run()

